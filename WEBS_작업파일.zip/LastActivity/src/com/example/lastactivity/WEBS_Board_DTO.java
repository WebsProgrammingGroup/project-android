package com.example.lastactivity;

public class WEBS_Board_DTO {
	String category;
	public WEBS_Board_DTO(String category){
		this.category =category;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
}
